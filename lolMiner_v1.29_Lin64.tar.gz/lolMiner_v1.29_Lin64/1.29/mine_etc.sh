#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=etchash.unmineable.com:13333
WALLET=ETH:0x353345ecFaB65550F33580e1E8CaEc9AcaAba048.First_Rig
#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETCHASH --pool etchash.unmineable.com:13333 --user ETH:0x353345ecFaB65550F33580e1E8CaEc9AcaAba048.First_Rig $@
